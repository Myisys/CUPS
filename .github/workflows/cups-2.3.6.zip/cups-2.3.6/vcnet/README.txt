README - CUPS on Windows - 2019-05-15
=====================================

This directory contains Visual Studio 2017 project and solution files for
building the CUPS library and cupstestppd, ippeveprinter, ippfind, ipptool,
testfile, and testhttp programs on Windows.
